<?php
include('constants.php');
include('dbopen.php');
$id=$_REQUEST['id'];
$page=$_REQUEST['page'];
$l=$_REQUEST['l'];
$t=$_REQUEST['t'];
$time= date('Y-m-d H:i:s');
mysqli_query($con,'INSERT INTO votes(tid, voter, created) VALUES ("'.$id.'", "'.$user.'","'.$time.'")');
header( 'Location: '.$page.'?id='.$l);
?>