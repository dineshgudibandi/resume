<?php include('constants.php'); ?>
<?php include('dbopen.php'); ?>
<?php include('header.php'); ?>
<body>
<div class="container" >
<h1><?php echo $apptitle; ?></h1>
<?php
$thispage="allleader.php";
$result = mysqli_query($con,'SELECT * FROM leaders  ORDER BY `Band` DESC');
$leader=true;
$owner=false;
if($result->num_rows == 0){
	echo $nolinks;
}else{
	$i=1;
	?>
	<table class='pure-table margintop20'>
    <thead>
        <tr>
            <th>#</th>
		    <th>Leader</th>
            <th>Designation</th>
        </tr>
    </thead>
    <tbody>
<?php
	while($row = mysqli_fetch_array($result)) {
	?>
		<tr <?php if($i % 2 == 0){ ?> class='pure-table-odd' <?php } ?> >
				<td><?php echo $i; ?></td>
				<td><?php echo "<a href='leader.php?id=".$row['name']."' >@".$row['name']."</a>"; ?></td>
				<td><?php echo $row['designation']; ?></td>
				</tr>
	<?php
	  $i++;
	} ?>
	<?php include('tableclose.php'); ?>
<?php } ?>
</div>
<body>
</html>
<?php include('dbclose.php'); ?>