<?php
include('constants.php');
include('dbopen.php');
$id=$_REQUEST['id'];
$boss=$_REQUEST['boss'];
$tweet=urlencode($_REQUEST['tweet']);
$page=$_REQUEST['page'];
	if($boss==""||$tweet==""){
		header( 'Location: '.$editlink.'?msg=101&id='.$id);
 	}else if($boss=='add'||$boss=='urls'){
	    header( 'Location: '.$editlink.'?msg=102&id='.$id);
	}else{
		$type=$_REQUEST['type'];
		$result = mysqli_query($con,'SELECT * FROM tweets WHERE boss="'.$boss.'" AND tweet="'.$tweet.'" AND id!="'.$id.'"');
		if($result->num_rows==0)
		{
			mysqli_query($con,'UPDATE tweets SET boss="'.$boss.'", tweet="'.$tweet.'", type="'.$type.'" WHERE id="'.$id.'"');
			header( 'Location: '.$page.'?msg=12');
		}else{
			header( 'Location: '.$editlink.'?msg=102&id='.$id);
		}
	}
include('dbclose.php');
?>