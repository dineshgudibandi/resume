<?php include('constants.php'); ?>
<?php include('dbopen.php'); ?>
<?php include('header.php'); ?>
<body>
<div class="container" >
<h1><?php 
$boss=$_REQUEST['id'];
echo $prefix.$boss; ?></h1>
<a class="pure-button button-success" href="<?php echo $addlink."?boss=".$boss; ?>"><?php echo $addlinktitle; ?></a>
<?php
$thispage="leader.php";
$result = mysqli_query($con,'SELECT tweets.id,tweet,boss,creator,type,COUNT(tid) AS votes FROM tweets LEFT JOIN votes ON tid = tweets.id WHERE boss="'.$boss.'" GROUP BY tweets.id ORDER BY `votes` DESC');
$leader=true;
$owner=false;
if($result->num_rows == 0){
	echo $nolinks;
}else{
	$i=1;
	?>
	<?php include('tableopen.php'); ?>
	<?php include('table.php'); ?>
	<?php include('tableclose.php'); ?>
<?php } ?>
</div>
<body>
</html>
<?php include('dbclose.php'); ?>