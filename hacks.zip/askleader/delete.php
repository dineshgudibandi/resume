<?php
include('constants.php');
include('dbopen.php');
$id=$_REQUEST['id'];
$page=$_REQUEST['page'];
$table=$_REQUEST['t'];
$result = mysqli_query($con,'DELETE FROM '.$table.' WHERE id="'.$id.'"');
header( 'Location: '.$page.'?msg=13');
?>