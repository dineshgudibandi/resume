<!doctype html>
<html lang="en">
<head>
<link rel='stylesheet' href='css/pure-min.css'>
<link rel="stylesheet" href="css/fonts.css" >
<link rel='stylesheet' href='css/styles.css'>
</head>