<?php
include('constants.php');
include('dbopen.php');
$id=$_REQUEST['id'];
$page=$_REQUEST['page'];
$l=$_REQUEST['l'];
$t=$_REQUEST['t'];
$result = mysqli_query($con,'DELETE FROM '.$t.' WHERE tid="'.$id.'" AND voter="'.$user.'"');
header( 'Location: '.$page.'?id='.$l);
?>