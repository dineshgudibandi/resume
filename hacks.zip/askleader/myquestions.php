<?php include('constants.php'); ?>
<?php include('dbopen.php'); ?>
<?php include('header.php'); ?>
<?php $thispage=$mylinks; ?>
<body>
<div class="container" >
<?php include("menu.php"); ?>
<?php
$result = mysqli_query($con,'SELECT * FROM tweets WHERE creator="'.$user.'"');
$owner=true;
if($result->num_rows == 0){
	echo $nolinks;
}else{
	echo "<h1>".$mylinkstitle."</h1>";
	$i=1;
	?>
	<?php include('tableopen.php'); ?>
	<?php include('table.php'); ?>
	<?php include('tableclose.php'); ?>
<?php } ?>
</div>
<body>
</html>
<?php include('dbclose.php'); ?>