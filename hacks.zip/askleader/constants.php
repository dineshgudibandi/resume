<?php
	session_start();
	$app="askleader";
	$prefix="@";
	$apptitle=$prefix."yourLeader";
	$user="";
	$isgrid=false;
	if(isset($_REQUEST['user'])){
	   $user.=$_REQUEST['user'];
	   $_SESSION['user']=$user;
	}else if(isset($_SESSION['user'])){
	   $user.=$_SESSION['user'];
	}else{
		$user.="reddy";
	}
	if(isset($_REQUEST['g'])){
	   $isgrid.=$_REQUEST['g'];
	   $_SESSION['g']=$isgrid;
	}else if(isset($_SESSION['g'])){
	   $isgrid.=$_SESSION['g'];
	}else{
		$isgrid.=true;
	}
	$messages = array(
	"11" => "<span class='button-success pad5' >Question Successfully Asked</span>",
    "12" => "<span class='button-success pad5' >Question Successfully Edited</span>",
	"13" => "<span class='button-success pad5' >Question Successfully Deleted</span>",
    "14" => "<span class='button-secondary pad5' >Keyword is not Used. Grab it before someone does!</span>",
    "101" => "<span class='button-error pad5' >Keyword and Link both needs to be filled</span>",
    "102" => "<span class='button-error pad5' >Keyword already exists. Please choose another one</span>",
	"103" => "",
    "104" => ""
	);
	$server=$_SERVER['REMOTE_ADDR'];
	//add 
	$addlink="add.php";
	$addlinktitle="Ask a Question";
	$access=array("1"=>"Self","2"=>"Anonymous");
	$addlabels=array(
	"action"=>"addtodb.php",
	"title"=>"Ask a Question",
	"label1"=>"Question for",
	"label2"=>"Question",
	"label3"=>"Ask as",
	"label4"=>"Ask",
	"id1"=>"boss",
	"id2"=>"tweet",
	"id3"=>"type",
	"id4"=>"id");
	//edit
	$editlink="edit.php";
	$editlabels=array(
	"action"=>"editindb.php",
	"title"=>"Edit your Question",
	"label1"=>"Question for",
	"label2"=>"Question",
	"label3"=>"Ask as",
	"label4"=>"Save Changes",
	"id1"=>"boss",
	"id2"=>"tweet",
	"id3"=>"type",
	"id4"=>"id");
	//mylinks
	$nolinks="<h1>You haven't asked any Questions.</h1><h2>Ask your leader a Question by clicking \"Ask a Question\"</h2>";
	$mylinks="myquestions.php";
	$mylinkstitle="Manage Your Questions";
	//public links
	$alllinks="allquestions.php";
	$alllinkstitle="All Questions";
	$votecount=0;
	$leader=false;
	$boss="";
	//$allleaders
	$allleaders="allleaders.php";
	$allleaderstitle="View Leaders";
	$disabled="";
?>