<?php if($isgrid){ ?>
<div class='pure-g-r grids'>
<?php }else{ ?>
<table class='pure-table margintop20'>
    <thead>
        <tr>
            <th>#</th>
			<?php if(!$leader){ ?>
            <th>Leader</th>
			<?php } ?>
            <th>Question</th>
			<th>Asked by</th>
			<?php if(!$leader){ ?>
				<?php if($owner){ ?>
					<th>Edit</th>
					<th>Delete</th>
					<?php }else{ ?>
					<th>Promote</th>
					<th>Votes#</th>
				<?php } ?>
			<?php }else{ ?>
			<th>Promote</th>
			<th>Votes#</th>
			<?php } ?>
        </tr>
    </thead>
    <tbody>
<?php } ?>