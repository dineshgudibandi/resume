<?php
include('constants.php');
include('dbopen.php');
$boss=$_REQUEST['boss'];
$tweet=urlencode($_REQUEST['tweet']);
	if($boss==""||$tweet==""){
		header( 'Location: '.$addlink.'?msg=101');
 	}else{
		$type=$_REQUEST['type'];
		$result = mysqli_query($con,'SELECT * FROM tweets WHERE boss="'.$boss.'" AND tweet="'.$tweet.'"');
		if($result->num_rows==0)
		{
		    $time= date('Y-m-d H:i:s');
			mysqli_query($con,'INSERT INTO tweets(boss, tweet, creator,created,type) VALUES ("'.$boss.'", "'.$tweet.'","'.$user.'","'.$time.'","'.$type.'")');
			header( 'Location: '.$mylinks.'?msg=11');
		}else{
			header( 'Location: '.$addlink.'?msg=102');
		}
	}
include('dbclose.php');
?>