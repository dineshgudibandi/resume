<?php if($isgrid){ ?>
</div>
<?php }else{ ?>
</tbody>
</table>
<?php } ?>