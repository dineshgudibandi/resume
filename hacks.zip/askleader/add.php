<?php include('constants.php'); ?>
<?php include('header.php'); ?>
<?php 
	$boss="";
	$tweet="";
	$type="1";
	$labels=$addlabels;
	$thispage=$addlink;
	if(isset($_REQUEST['boss'])){
		$boss.=$_REQUEST['boss'];
		$disabled.="readonly";
	}
?> 
<body>
<div class="container">
<?php include("menu.php"); ?>
<?php include('form.php'); ?>
</div>
</body>
</html>