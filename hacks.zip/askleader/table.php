<?php
	while($row = mysqli_fetch_array($result)) {
		$type=$row['type'];
		$creator= $row['creator'];
		$boss=$row['boss'];
		$tweet=urldecode($row['tweet']);
		$id=$row['id'];
		 $myvotes = mysqli_query($con,'SELECT count(*) as votes FROM votes WHERE tid="'.$id.'" AND voter="'.$user.'"');
		 $mynumvotes=mysqli_fetch_row($myvotes);
		
	?><?php if($isgrid){ ?>
		<div class='pure-u-1-4 divbox'>
			<div class='pure-g-r'>
				<div class='pure-u-1-8 '>#<?php echo $i; ?></div> 
				<div class='pure-u-3-8 '><?php if(!$leader){ echo "<a href='leader.php?id=".$boss."' >@".$boss."</a>"; } ?></div>
				<div class='pure-u-3-8 right'><?php if($type==1){?><a href="https://mysites.aexp.com/Person.aspx?accountname=ADS%5C<?php echo $creator; ?>" ><?php echo $creator; ?></a> <?php }else{ echo $access[2]; } ?></div>
			</div>
			<div class='pure-g-r'>
				<div class='pure-u-1-1'><p class=''><?php echo $tweet; ?></p></div>
			</div>
			<div class='pure-g-r'>
			   <?php if(!$leader){ ?>
						<?php if($owner){ ?>
							<div class='pure-u-1-3 '><a class="pure-button button-secondary" href="edit.php?id=<?php echo $id; ?>&page=<?php echo $thispage; ?>">edit</a></div>
							<div class='pure-u-1-3 right'><a class="pure-button button-error" href="delete.php?id=<?php echo $id; ?>&page=<?php echo $thispage; ?>&t=tweets">delete</a></div>
						<?php }else{ $votes=$row['votes']; ?>
							<div class='pure-u-1-3 '><a class="pure-button button-secondary">Votes#: <?php echo $votes; ?></a></div> 
							<div class='pure-u-1-3 right'>
							<?php if($mynumvotes[0]==0){?>
							<a class="pure-button button-success" href="vote.php?id=<?php echo $id; ?>&l=<?php echo $boss; ?>&page=<?php echo $thispage; ?>">Promote</a>
							<?php }else{ ?>
							<a class="pure-button button-error" href="unvote.php?id=<?php echo $id; ?>&l=<?php echo $boss; ?>&page=<?php echo $thispage; ?>&t=votes">Demote</a>
							<?php } ?></div> 
						<?php } ?>
				<?php }else{ $votes=$row['votes']; ?>
						<div class='pure-u-1-3 '><a class="pure-button button-secondary">Votes#: <?php echo $votes; ?></a></div> 
						<div class='pure-u-1-3 right'>
						<?php if($mynumvotes[0]==0){?>
							<a class="pure-button button-success" href="vote.php?id=<?php echo $id; ?>&l=<?php echo $boss; ?>&page=<?php echo $thispage; ?>">Promote</a>
						<?php }else{ ?>
							<a class="pure-button button-error" href="unvote.php?id=<?php echo $id; ?>&l=<?php echo $boss; ?>&page=<?php echo $thispage; ?>&t=votes">Demote</a>
						<?php } ?></div> 
				<?php } ?>
			</div>
		</div>
		<?php }else{ ?>
		<tr <?php if($i % 2 == 0){ ?> class='pure-table-odd' <?php } ?> >
				<td><?php echo $i; ?></td>
				<?php if(!$leader){ ?>
				<td><?php echo "<a href='leader.php?id=".$boss."' >@".$boss."</a>"; ?></td>
				<?php } ?>
				<td><?php echo $tweet; ?></td>
				<td><?php if($type==1){?><a href="https://mysites.aexp.com/Person.aspx?accountname=ADS%5C<?php echo $creator; ?>" ><?php echo $creator; ?></a> <?php }else{ echo $access[2]; } ?></td>
				<?php if(!$leader){ ?>
					<?php if($owner){ ?>
					<td><a class="pure-button button-secondary" href="edit.php?id=<?php echo $id; ?>&page=<?php echo $thispage; ?>">edit</a></td>
					<td><a class="pure-button button-error" href="delete.php?id=<?php echo $id; ?>&page=<?php echo $thispage; ?>&t=urls">delete</a></td>
					<?php }else{  $votes=$row['votes']; 
					 if($mynumvotes[0]==0){
					 ?>
					<td><a class="pure-button button-success" href="vote.php?id=<?php echo $id; ?>&l=<?php echo $boss; ?>&page=<?php echo $thispage; ?>">Promote</a></td>
					<?php }else{ ?>
					<td><a class="pure-button button-error" href="unvote.php?id=<?php echo $id; ?>&l=<?php echo $boss; ?>&page=<?php echo $thispage; ?>&t=votes">Demote</a></td>
					<?php } ?>
					<td><a class="pure-button button-secondary"><?php echo $votes; ?></a></td>
					<?php } ?>
				<?php }else{ 
					 $votes=$row['votes']; 
					 if($mynumvotes[0]==0){
					 ?>
					<td><a class="pure-button button-success" href="vote.php?id=<?php echo $id; ?>&l=<?php echo $boss; ?>&page=<?php echo $thispage; ?>">Promote</a></td>
					<?php }else{ ?>
					<td><a class="pure-button button-error" href="unvote.php?id=<?php echo $id; ?>&l=<?php echo $boss; ?>&page=<?php echo $thispage; ?>&t=votes">Demote</a></td>
					<?php } ?>
					<td><a class="pure-button button-secondary"><?php echo $votes; ?></a></td>
				<?php } ?>
		</tr>
		<?php } ?>
	<?php
	  $i++;
	} ?>