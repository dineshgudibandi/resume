<link rel="stylesheet" href="css/jquery-ui.css">
<script src="js/jquery-1.10.2.js"></script>
<script src="js/jquery-ui.js"></script>
<script>
$(function() {
	var availableTags = [<?php echo $tags; ?>];
	$( "#<?php echo $labels["id1"]; ?>" ).autocomplete({source: availableTags});
});
</script>