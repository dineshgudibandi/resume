<?php
include("ax/constants.php");
include($app."/dbopen.php");
$new=true;
if(!isset($_REQUEST["id"])){
$case="urls";
}else{
$case=$_REQUEST["id"];
}
      $url="";
      switch ($case) {
   	    case "add":  $url.=$app."/add.php";
		             $new=false;
                     break;
		case "urls": $url.=$app."/mylinks.php";
					 $new=false;
                     break;
      }
if($url==""){
	$result = mysqli_query($con,'SELECT * FROM urls WHERE keyword="'.$case.'"');
	while($row = mysqli_fetch_array($result)) {
		$url.=urldecode($row['url']);
		 $new=false;
	}
}
include($app."/dbclose.php");
if($new){
	$url.=$app."/add.php?msg=14&key=".$case;
}
header( 'Location: '.$url ) ;
?>