-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 26, 2014 at 07:39 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `axpdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE IF NOT EXISTS `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `type` int(1) NOT NULL,
  `creator` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `name`, `description`, `type`, `creator`, `created`) VALUES
(1, 'test', 'dsasadsa', 1, 'reddy', '2014-05-26 11:04:09');

-- --------------------------------------------------------

--
-- Table structure for table `eventvotes`
--

CREATE TABLE IF NOT EXISTS `eventvotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tid` int(11) NOT NULL,
  `voter` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `eventvotes`
--

INSERT INTO `eventvotes` (`id`, `tid`, `voter`, `created`) VALUES
(2, 6, 'reddy', '2014-05-26 10:36:16');

-- --------------------------------------------------------

--
-- Table structure for table `leaders`
--

CREATE TABLE IF NOT EXISTS `leaders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `designation` varchar(200) NOT NULL,
  `band` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `leaders`
--

INSERT INTO `leaders` (`id`, `name`, `designation`, `band`) VALUES
(1, 'Jeff', 'SVP', 45),
(2, 'Ken', 'CEO', 100),
(3, 'Marc', 'CIO', 90),
(4, 'Prakash', 'Director', 40);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `event` varchar(100) NOT NULL,
  `post` varchar(1000) NOT NULL,
  `creator` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `type` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `event`, `post`, `creator`, `created`, `type`) VALUES
(6, 'test', 'test+hack', 'reddy', '2014-05-26 10:33:12', 1),
(7, 'test', 'test+hack+2', 'reddy', '2014-05-26 02:32:21', 1),
(8, 'ewrewrrew', 'hjdsadas', 'reddy', '2014-05-26 11:16:44', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tweets`
--

CREATE TABLE IF NOT EXISTS `tweets` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `boss` varchar(100) NOT NULL,
  `tweet` varchar(1000) NOT NULL,
  `creator` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `type` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tweets`
--

INSERT INTO `tweets` (`id`, `boss`, `tweet`, `creator`, `created`, `type`) VALUES
(1, 'Jeff', 'test+question', 'reddy', '2014-05-25 09:55:32', 2),
(2, 'Jeff', '2nd+question', 'reddy', '2014-05-25 19:03:42', 1),
(4, 'Ken', 'this+is+a+test+question+by+dinesh', 'dinesh', '2014-05-25 21:54:48', 2),
(5, 'ken', 'gdkhasjdjsad', 'dinesh', '2014-05-26 05:28:38', 1);

-- --------------------------------------------------------

--
-- Table structure for table `urls`
--

CREATE TABLE IF NOT EXISTS `urls` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `keyword` varchar(100) NOT NULL,
  `url` varchar(1000) NOT NULL,
  `creator` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `type` int(2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `keyword` (`keyword`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `urls`
--

INSERT INTO `urls` (`id`, `keyword`, `url`, `creator`, `created`, `type`) VALUES
(7, 'jobs', 'https%3A%2F%2Fsquare.aexp.com%2FMyLife-Career%2FRecruitment%2FPages%2FRecruitment.aspx%3Fintcmp%3Djobsmegamenu', 'dgudiban', '2014-05-24 11:47:29', 1),
(8, 'Expenses', 'https%3A%2F%2Fsquare.aexp.com%2FMyTools%2FGBS%2FPages%2FGBSTools.aspx%3FactiveTab%3DExpenses%26intcmp%3Dhomepageexpenses', 'dgudiban', '2014-05-24 20:47:00', 1),
(17, 'travel', 'https%3A%2F%2Fsquare.aexp.com%2FMyTools%2FGBS%2FPages%2FGBSTools.aspx%3FactiveTab%3DTravel%26intcmp%3Dhomepagetravel', 'kraju10', '2014-05-24 23:03:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE IF NOT EXISTS `votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tid` int(11) NOT NULL,
  `voter` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49 ;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`id`, `tid`, `voter`, `created`) VALUES
(42, 6, 'dinesh', '2014-05-26 06:30:21'),
(44, 4, 'dinesh', '2014-05-26 06:54:14'),
(45, 5, 'dinesh', '2014-05-26 06:54:15'),
(46, 1, 'dinesh', '2014-05-26 06:54:17'),
(47, 2, 'dinesh', '2014-05-26 06:54:18'),
(48, 6, 'reddy', '2014-05-26 10:33:20');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
