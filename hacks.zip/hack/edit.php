<?php
include('constants.php');
include('dbopen.php');
$id=$_REQUEST['id'];
$result = mysqli_query($con,'SELECT * FROM urls WHERE id="'.$id.'"');
while($row = mysqli_fetch_array($result)) {
$keyword=$row['keyword'];
$url=urldecode($row['url']);
$type=$row['type'];
}
?>
<html>
<head>
</head>
<body>
<div style="margin:auto;width:800px;margin-top:50px;" >
<?php include("menu.php"); ?>
<div style="margin:10px 0px 10px 0px;">
<?php if(isset($_REQUEST['msg'])){
echo $messages[$_REQUEST['msg']];
}
?> 
</div>
<form class="pure-form pure-form-stacked" action="editindb.php" method="post">
    <fieldset>
        <legend>Edit Your Url</legend>
        <label for="keyword">Keyword</label>
        <input id="key" name="key" type="text" placeholder="Keyword" class="pure-input-1" required value="<?php echo $keyword; ?>">

        <label for="url">Url</label>
        <textarea id="url" name="url" placeholder="Url" class="pure-input-1" required><?php echo $url;?></textarea>

        <label for="type">Url Type</label>
        <select id="type" name="type" class="pure-input-1-4">
            <option value="1" <?php if($type==1){ echo 'selected'; } ?>>Public</option>
            <option value="2" <?php if($type==2){ echo 'selected'; } ?>>Private</option>
        </select>
		<input type="hidden" name="id" id="id" value="<?php echo $id; ?>" />
        <button type="submit" class="pure-button pure-button-primary">Add</button>
    </fieldset>
</form>
</div>
</body>
</html>