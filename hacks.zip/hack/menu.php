<h1>Miniature Links</h1>
<?php echo "Hello ".$user."!"; ?><br/>
<a class="pure-button button-success" href="add.php">Add New Link</a>
<a class="pure-button button-secondary" href="mylinks.php">Manage My Links</a>
<a class="pure-button button-warning" href="alllinks.php">View Public Links</a>