<?php
include('constants.php');
include('dbopen.php');
$result = mysqli_query($con,'SELECT * FROM urls WHERE creator="'.$user.'"');
?>
<html>
<head>
</head>
<body>
<div style="margin:auto;width:800px;margin-top:50px;" >
<?php include("menu.php"); ?>
<div style="margin:10px 0px 10px 0px;">
<?php if(isset($_REQUEST['msg'])){
echo $messages[$_REQUEST['msg']];
}
?> </div>
<?php
if($result->num_rows==0){
?><h1>You haven't created any links.</h1><h2>Create your first link by clicking Add New Link</h2>
<?php
}else{
?>
<h2>My Links </h2>
<table class='pure-table' style="margin-top:20px">
    <thead>
        <tr>
            <th>#</th>
            <th>Alias</th>
            <th>Url</th>
			<th>Owner</th>
            <th>Type</th>
			<th>Edit</th>
			<th>Delete</th>
        </tr>
    </thead>
    <tbody>
<?php
$i=1;
while($row = mysqli_fetch_array($result)) {
?>
 	<tr <?php if($i % 2 == 0){ ?> class='pure-table-odd' <?php } ?> >
            <td><?php echo $i; ?></td>
            <td><?php echo "<a href='http://".$server."/".$row['keyword']."' target='_blank'>".$row['keyword']."</a>"; ?></td>
            <td><?php echo urldecode($row['url']); ?></td>
			<td><a href="https://mysites.aexp.com/Person.aspx?accountname=ADS%5C<?php echo $row['creator']; ?>" ><?php echo $row['creator']; ?></a></td>
            <td><?php if($row['type']==1){echo 'Public';}else{ echo 'Private';} ?></td>
			<td><a class="pure-button button-secondary" href="edit.php?id=<?php echo $row['id']; ?>">edit</a></td>
			<td><a class="pure-button button-error" href="delete.php?id=<?php echo $row['id']; ?>&page=mylinks">delete</a></td>
        </tr>
  <?php
  $i++;
  } ?>
</tbody>
</table>
<?php
}
?>
</div>
<body>
</html>
  <?php
include('dbclose.php');
?>