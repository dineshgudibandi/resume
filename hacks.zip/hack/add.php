<?php
include('constants.php');
?>
<html>
<head>
</head>
<body>
<div style="margin:auto;width:800px;margin-top:50px;" >
<?php include("menu.php"); ?>
<div style="margin:10px 0px 10px 0px;"><?php if(isset($_REQUEST['msg'])){
echo $messages[$_REQUEST['msg']];
}
$key="";
if(isset($_REQUEST['key'])){
$key.=$_REQUEST['key'];
}
?> </div>

<form class="pure-form pure-form-stacked" action="addtodb.php" method="post">
    <fieldset>
        <legend>Add Your Url</legend>
        <label for="keyword">Keyword</label>
        <input id="key" name="key" type="text" placeholder="Keyword" class="pure-input-1" value="<?php echo $key; ?>" required>

        <label for="url">Url</label>
        <textarea id="url" name="url" placeholder="Url" class="pure-input-1" required></textarea>

        <label for="type">Url Type</label>
        <select id="type" name="type" class="pure-input-1-4">
            <option value="1">Public</option>
            <option value="2">Private</option>
        </select>
        <button type="submit" class="pure-button pure-button-primary">Add</button>
    </fieldset>
</form>
</div>
</body>
</html>