<?php
	session_start();
	$app="ax";
	$user="";
	if(isset($_REQUEST['user'])){
	   $user.=$_REQUEST['user'];
	   $_SESSION['user']=$user;
	}else if(isset($_SESSION['user'])){
	   $user.=$_SESSION['user'];
	}else{
		$user.="reddy";
	}
	$messages = array(
	"11" => "<span class='button-success' style='padding:5px;'>Miniature Link Successfully Created</span>",
    "12" => "<span class='button-success' style='padding:5px;'>Miniature Link Successfully Edited</span>",
	"13" => "<span class='button-success' style='padding:5px;'>Miniature Link Successfully Deleted</span>",
    "14" => "<span class='button-secondary' style='padding:5px;'>Keyword is not Used. Grab it before someone does!</span>",
    "101" => "<span class='button-error' style='padding:5px;'>Keyword and URL both needs to be filled</span>",
    "102" => "<span class='button-error' style='padding:5px;'>Keyword already exists. Please choose another one</span>",
	"103" => "",
    "104" => "",
	);
	$server=$_SERVER['REMOTE_ADDR'];
?>
<link rel='stylesheet' href='http://yui.yahooapis.com/pure/0.4.2/pure-min.css'>
<style>

        .button-success,
        .button-error,
        .button-warning,
        .button-secondary {
            color: white;
            border-radius: 4px;
            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);
        }

        .button-success {
            background: rgb(28, 184, 65); /* this is a green */
        }

        .button-error {
            background: rgb(202, 60, 60); /* this is a maroon */
        }

        .button-warning {
            background: rgb(223, 117, 20); /* this is an orange */
        }

        .button-secondary {
            background: rgb(66, 184, 221); /* this is a light blue */
        }

    </style>