<?php
	session_start();
	$app="HackTrackr";
	$prefix="";
	$apptitle=$prefix."HackTrackr";
	$user="";
	$isgrid=false;
	if(isset($_REQUEST['user'])){
	   $user.=$_REQUEST['user'];
	   $_SESSION['user']=$user;
	}else if(isset($_SESSION['user'])){
	   $user.=$_SESSION['user'];
	}else{
		$user.="reddy";
	}
	if(isset($_REQUEST['g'])){
	   $isgrid.=$_REQUEST['g'];
	   $_SESSION['g']=$isgrid;
	}else if(isset($_SESSION['g'])){
	   $isgrid.=$_SESSION['g'];
	}else{
		$isgrid.=true;
	}
	$messages = array(
	"11" => "<span class='button-success pad5' >Post Successfully Added</span>",
    "12" => "<span class='button-success pad5' >Post Successfully Edited</span>",
	"13" => "<span class='button-success pad5' >Post Successfully Deleted</span>",
    "14" => "<span class='button-secondary pad5' >Keyword is not Used. Grab it before someone does!</span>",
    "101" => "<span class='button-error pad5' >Event and Post both needs to be filled</span>",
    "102" => "<span class='button-error pad5' >Event already exists. Please choose another one</span>",
	"103" => "",
    "104" => ""
	);
	$server=$_SERVER['REMOTE_ADDR'];
	//add 
	$addlink="add.php";
	$addlinktitle="Add your Hack";
	$access=array("1"=>"Active","2"=>"Inactive");
	$addlabels=array(
	"action"=>"addtodb.php",
	"title"=>"Add your Hack",
	"label1"=>"Hacking for",
	"label2"=>"Hack Description",
	"label3"=>"Hack Status",
	"label4"=>"Post",
	"id1"=>"event",
	"id2"=>"post",
	"id3"=>"type",
	"id4"=>"id");
	$addeventlabels=array(
	"action"=>"addeventtodb.php",
	"title"=>"Add your Event",
	"label1"=>"Event Name",
	"label2"=>"Event Description",
	"label3"=>"Event Status",
	"label4"=>"Add",
	"id1"=>"name",
	"id2"=>"description",
	"id3"=>"type",
	"id4"=>"id");
	//edit
	$editlink="edit.php";
	$editlabels=array(
	"action"=>"editindb.php",
	"title"=>"Edit your Post",
	"label1"=>"Hacking for",
	"label2"=>"Hack Description",
	"label3"=>"Hack Status",
	"label4"=>"Post",
	"id1"=>"event",
	"id2"=>"post",
	"id3"=>"type",
	"id4"=>"id");
	//mylinks
	$nolinks="<h1>You haven't submitted any Hacks.</h1><h2>you can submit your hack by clicking \"Add your Hack\"</h2>";
	$noevents="<h1>There are no events Active at this time</h2>";
	$mylinks="myhacks.php";
	$mylinkstitle="Manage Your Hacks";
	//public links
	$alllinks="allhacks.php";
	$alllinkstitle="All Hacks";
	$votecount=0;
	$leader=false;
	$event="";
	//$allleaders
	$allleaders="allevents.php";
	$allleaderstitle="View Events";
	$disabled="";
	$addevent="addevent.php";
	$addeventlinktitle="Add New Event";
?>