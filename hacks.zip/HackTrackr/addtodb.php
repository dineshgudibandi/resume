<?php
include('constants.php');
include('dbopen.php');
$event=$_REQUEST['event'];
$post=urlencode($_REQUEST['post']);
	if($event==""||$post==""){
		header( 'Location: '.$addlink.'?msg=101');
 	}else{
		$type=$_REQUEST['type'];
		$result = mysqli_query($con,'SELECT * FROM posts WHERE event="'.$event.'" AND post="'.$post.'"');
		if($result->num_rows==0)
		{
		    $time= date('Y-m-d H:i:s');
			mysqli_query($con,'INSERT INTO posts(event, post, creator,created,type) VALUES ("'.$event.'", "'.$post.'","'.$user.'","'.$time.'","'.$type.'")');
			header( 'Location: '.$mylinks.'?msg=11');
		}else{
			header( 'Location: '.$addlink.'?msg=102');
		}
	}
include('dbclose.php');
?>