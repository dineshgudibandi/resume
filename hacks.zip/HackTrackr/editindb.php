<?php
include('constants.php');
include('dbopen.php');
$id=$_REQUEST['id'];
$event=$_REQUEST['event'];
$post=urlencode($_REQUEST['post']);
$page=$_REQUEST['page'];
	if($event==""||$post==""){
		header( 'Location: '.$editlink.'?msg=101&id='.$id);
 	}else if($event=='add'||$event=='urls'){
	    header( 'Location: '.$editlink.'?msg=102&id='.$id);
	}else{
		$type=$_REQUEST['type'];
		$result = mysqli_query($con,'SELECT * FROM posts WHERE event="'.$event.'" AND post="'.$post.'" AND id!="'.$id.'"');
		if($result->num_rows==0)
		{
			mysqli_query($con,'UPDATE posts SET event="'.$event.'", post="'.$post.'", type="'.$type.'" WHERE id="'.$id.'"');
			header( 'Location: '.$page.'?msg=12');
		}else{
			header( 'Location: '.$editlink.'?msg=102&id='.$id);
		}
	}
include('dbclose.php');
?>