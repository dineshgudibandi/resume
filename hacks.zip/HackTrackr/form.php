<?php include("dbopen.php"); ?>
<?php
$result = mysqli_query($con,'SELECT name FROM events');
$tags="";
if($result->num_rows>0){
	while($row = mysqli_fetch_array($result)) {
	  $tags.='"'.$row['name'].'",';
	}
}
?>
<?php include("dbclose.php"); ?>
<?php include("autoComplete.php"); ?>
<form class="pure-form pure-form-stacked" action="<?php echo $labels["action"]; ?>" method="post">
    <fieldset>
        <legend><?php echo $labels["title"]; ?></legend>
        <label for="<?php echo $labels["id1"]; ?>"><?php echo $labels["label1"]; ?></label>
        <input id="<?php echo $labels["id1"]; ?>" name="<?php echo $labels["id1"]; ?>" type="text" placeholder="<?php echo $labels["label1"]; ?>" class="pure-input-1" value="<?php echo $event; ?>" required="" <?php echo $disabled; ?>>

        <label for="<?php echo $labels["id2"]; ?>"><?php echo $labels["label2"]; ?></label>
        <textarea id="<?php echo $labels["id2"]; ?>" name="<?php echo $labels["id2"]; ?>" placeholder="<?php echo $labels["label2"]; ?>" class="pure-input-1" required><?php echo $post; ?></textarea>

        <label for="<?php echo $labels["id3"]; ?>"><?php echo $labels["label3"]; ?></label>
        <select id="<?php echo $labels["id3"]; ?>" name="<?php echo $labels["id3"]; ?>" class="pure-input-1-4">
            <option value="1" <?php if($type==1){ echo 'selected'; } ?>><?php echo $access['1'];?></option>
            <option value="2" <?php if($type==2){ echo 'selected'; } ?>><?php echo $access['2'];?></option>
        </select>
		<input type="hidden" name="id" id="id" value="<?php echo $id; ?>" />
		<input type="hidden" name="page" id="page" value="<?php if(isset($_REQUEST['page'])){ echo $_REQUEST['page']; } ?>" />
        <button type="submit" class="pure-button pure-button-primary"><?php echo $labels["label4"]; ?></button>
    </fieldset>
</form>