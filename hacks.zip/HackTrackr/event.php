<?php include('constants.php'); ?>
<?php include('dbopen.php'); ?>
<?php include('header.php'); ?>
<body>
<div class="container" >
<h1><?php 
$event=$_REQUEST['id'];
echo $prefix.$event; ?></h1>
<a class="pure-button button-success" href="<?php echo $addlink."?event=".$event; ?>"><?php echo $addlinktitle; ?></a>
<?php
$thispage="event.php";
$result = mysqli_query($con,'SELECT posts.id,post,event,creator,type,COUNT(tid) AS votes FROM posts LEFT JOIN eventvotes ON tid = posts.id WHERE event="'.$event.'" GROUP BY posts.id ORDER BY `votes` DESC');
$leader=true;
$owner=false;
if($result->num_rows == 0){
	echo $nolinks;
}else{
	$i=1;
	?>
	<?php include('tableopen.php'); ?>
	<?php include('table.php'); ?>
	<?php include('tableclose.php'); ?>
<?php } ?>
</div>
<body>
</html>
<?php include('dbclose.php'); ?>