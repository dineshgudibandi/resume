<h1><?php if($event!=""){echo $prefix.$event;}else{ echo $apptitle; }?></h1>
<?php echo "Hello ".$user."!"; ?><br/>
<a class="pure-button button-success" href="<?php echo $addlink; ?>"><?php echo $addlinktitle; ?></a>
<a class="pure-button button-secondary" href="<?php echo $mylinks; ?>"><?php echo $mylinkstitle; ?></a>
<a class="pure-button button-warning" href="<?php echo $alllinks; ?>"><?php echo $alllinkstitle; ?></a>
<a class="pure-button " href="<?php echo $allleaders; ?>"><?php echo $allleaderstitle; ?></a>
<?php if($thispage==$mylinks||$thispage==$alllinks){?>
<a class="pure-button right" href="<?php echo $thispage; ?>?g=<?php echo !$isgrid; ?>"><?php if($isgrid){ echo "Switch to : Table";}else{ echo "Switch to : Grid";} ?></a>
<?php } ?>
<div class="message">
<?php if(isset($_REQUEST['msg'])){
echo $messages[$_REQUEST['msg']];
}
?> 
</div>