<?php include('constants.php'); ?>
<?php include('dbopen.php'); ?>
<?php include('header.php'); ?>
<body>
<div class="container" >
<h1><?php echo $apptitle; ?></h1>
<?php echo "Hello ".$user."!"; ?><br/>
<a class="pure-button button-success" href="<?php echo $addevent; ?>"><?php echo $addeventlinktitle; ?></a>
<?php
$thispage=$allleaders;
$result = mysqli_query($con,'SELECT * FROM events');
$leader=true;
$owner=false;
if($result->num_rows == 0){
	echo $noevents;
}else{
	$i=1;
	?>
	<table class='pure-table margintop20'>
    <thead>
        <tr>
            <th>#</th>
		    <th>Event</th>
            <th>Description</th>
        </tr>
    </thead>
    <tbody>
<?php
	while($row = mysqli_fetch_array($result)) {
	?>
		<tr <?php if($i % 2 == 0){ ?> class='pure-table-odd' <?php } ?> >
				<td><?php echo $i; ?></td>
				<td><?php echo "<a href='event.php?id=".$row['name']."' >@".$row['name']."</a>"; ?></td>
				<td><?php echo $row['description']; ?></td>
				</tr>
	<?php
	  $i++;
	} ?>
	<?php include('tableclose.php'); ?>
<?php } ?>
</div>
<body>
</html>
<?php include('dbclose.php'); ?>