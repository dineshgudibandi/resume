<?php include('constants.php'); ?>
<?php include('header.php'); ?>
<?php 
	$event="";
	$post="";
	$type="1";
	$labels=$addlabels;
	$thispage=$addlink;
	if(isset($_REQUEST['event'])){
		$event.=$_REQUEST['event'];
		$disabled.="readonly";
	}
?> 
<body>
<div class="container">
<?php include("menu.php"); ?>
<?php include('form.php'); ?>
</div>
</body>
</html>