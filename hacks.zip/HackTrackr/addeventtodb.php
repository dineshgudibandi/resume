<?php
include('constants.php');
include('dbopen.php');
$name=$_REQUEST['name'];
$description=urlencode($_REQUEST['description']);
	if($name==""||$description==""){
		header( 'Location: '.$addeventlink.'?msg=101');
 	}else{
		$type=$_REQUEST['type'];
		$result = mysqli_query($con,'SELECT * FROM events WHERE name="'.$name.'"');
		if($result->num_rows==0)
		{
		    $time= date('Y-m-d H:i:s');
			mysqli_query($con,'INSERT INTO events(name, description, creator,created,type) VALUES ("'.$name.'", "'.$description.'","'.$user.'","'.$time.'","'.$type.'")');
			header( 'Location: '.$allleaders.'?msg=11');
		}else{
			header( 'Location: '.$addevent.'?msg=102');
		}
	}
include('dbclose.php');
?>