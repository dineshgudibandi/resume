<?php include('constants.php'); ?>
<?php include('header.php'); ?>
<?php 
	$name="";
	$description="";
	$type="1";
	$event="";
	$post="";
	$labels=$addeventlabels;
	$thispage=$addevent;
	if(isset($_REQUEST['name'])){
		$name.=$_REQUEST['name'];
		$disabled.="readonly";
	}
	$event=$name;
	
?> 
<body>
<div class="container">
<?php include("menu.php"); ?>
<?php include('form.php'); ?>
</div>
</body>
</html>