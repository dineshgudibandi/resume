<?php
include('constants.php');
include('dbopen.php');
$id=$_REQUEST['id'];
$page=$_REQUEST['page'];
$result = mysqli_query($con,'DELETE FROM urls WHERE id="'.$id.'"');
header( 'Location: '.$page.'?msg=13');
?>