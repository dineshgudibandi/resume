<?php
	session_start();
	$app="ax";
	$apptitle="Miniature Links";
	$user="";
	if(isset($_REQUEST['user'])){
	   $user.=$_REQUEST['user'];
	   $_SESSION['user']=$user;
	}else if(isset($_SESSION['user'])){
	   $user.=$_SESSION['user'];
	}else{
		$user.="reddy";
	}
	$messages = array(
	"11" => "<span class='button-success pad5' >Miniature Link Successfully Created</span>",
    "12" => "<span class='button-success pad5' >Miniature Link Successfully Edited</span>",
	"13" => "<span class='button-success pad5' >Miniature Link Successfully Deleted</span>",
    "14" => "<span class='button-secondary pad5' >Keyword is not Used. Grab it before someone does!</span>",
    "101" => "<span class='button-error pad5' >Keyword and Link both needs to be filled</span>",
    "102" => "<span class='button-error pad5' >Keyword already exists. Please choose another one</span>",
	"103" => "",
    "104" => ""
	);
	$server=$_SERVER['REMOTE_ADDR'];
	//add 
	$addlink="add.php";
	$addlinktitle="Create New Link";
	$access=array("1"=>"Public","2"=>"Private");
	$addlabels=array(
	"action"=>"addtodb.php",
	"title"=>"Create New Link",
	"label1"=>"Keyword",
	"label2"=>"Link",
	"label3"=>"Link Type",
	"label4"=>"Add",
	"id1"=>"key",
	"id2"=>"url",
	"id3"=>"type",
	"id4"=>"id");
	//edit
	$editlink="edit.php";
	$editlabels=array(
	"action"=>"editindb.php",
	"title"=>"Edit Your Link",
	"label1"=>"Keyword",
	"label2"=>"Link",
	"label3"=>"Link Type",
	"label4"=>"Save Changes",
	"id1"=>"key",
	"id2"=>"url",
	"id3"=>"type",
	"id4"=>"id");
	//mylinks
	$nolinks="<h1>You haven't created any links.</h1><h2>Create your first link by clicking Add New Link</h2>";
	$mylinks="mylinks.php";
	$mylinkstitle="Manage Your Links";
	//public links
	$alllinks="alllinks.php";
	$alllinkstitle="Public Links";
?>