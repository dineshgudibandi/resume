<?php
	while($row = mysqli_fetch_array($result)) {
		$type=$row['type'];
	?>
		<tr <?php if($i % 2 == 0){ ?> class='pure-table-odd' <?php } ?> >
				<td><?php echo $i; ?></td>
				<td><?php echo "<a href='http://".$server."/".$row['keyword']."' target='_blank'>".$row['keyword']."</a>"; ?></td>
				<td><?php echo urldecode($row['url']); ?></td>
				<td><a href="https://mysites.aexp.com/Person.aspx?accountname=ADS%5C<?php echo $row['creator']; ?>" ><?php echo $row['creator']; ?></a></td>
				<td><?php echo $access[$type]; ?></td>
				<?php if($owner){ ?>
				<td><a class="pure-button button-secondary" href="edit.php?id=<?php echo $row['id']; ?>&page=<?php echo $thispage; ?>">edit</a></td>
				<td><a class="pure-button button-error" href="delete.php?id=<?php echo $row['id']; ?>&page=<?php echo $thispage; ?>">delete</a></td>
				<?php }else{ ?>
				<td><a class="pure-button button-secondary pure-button-disabled" >edit</a></td>
				<td><a class="pure-button button-error pure-button-disabled" >delete</a></td>
			 <?php } ?>
		</tr>
	<?php
	  $i++;
	} ?>