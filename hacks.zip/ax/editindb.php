<?php
include('constants.php');
include('dbopen.php');
$id=$_REQUEST['id'];
$key=$_REQUEST['key'];
$url=urlencode($_REQUEST['url']);
$page=$_REQUEST['page'];
	if($key==""||$url==""){
	echo $url;
	exit;
		header( 'Location: '.$editlink.'?msg=101&id='.$id);
 
	}else if($key=='add'||$key=='urls'){
	    header( 'Location: '.$editlink.'?msg=102&id='.$id);
	}else{
		$type=$_REQUEST['type'];
		$result = mysqli_query($con,'SELECT * FROM urls WHERE keyword="'.$key.'" AND id !="'.$id.'"');
		if($result->num_rows==0)
		{
			mysqli_query($con,'UPDATE urls SET keyword="'.$key.'", url="'.$url.'", type="'.$type.'" WHERE id="'.$id.'"');
			header( 'Location: '.$page.'?msg=12');
		}else{
			header( 'Location: '.$editlink.'?msg=102&id='.$id);
		}
	}
include('dbclose.php');
?>