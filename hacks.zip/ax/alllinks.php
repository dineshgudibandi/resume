<?php include('constants.php'); ?>
<?php include('dbopen.php'); ?>
<?php include('header.php'); ?>
<body>
<div class="container" >
<?php include("menu.php"); ?>
<?php
$thispage=$alllinks;
$result = mysqli_query($con,'SELECT * FROM urls WHERE creator="'.$user.'" AND type="1"');
$public = mysqli_query($con,'SELECT * FROM urls WHERE creator!="'.$user.'" AND type="1"');
$owner=true;
if($result->num_rows == 0){
    $result = $public;
	if($result->num_rows == 0){
		echo $nolinks;
	}else{
		echo "<h1>".$alllinkstitle."</h1>";
		$i=1;
		$owner=false;
		?>
		<?php include('tableopen.php'); ?>
		<?php include('table.php'); ?>
		<?php include('tableclose.php'); ?>
	<?php } 
}else{
	echo "<h1>".$alllinkstitle."</h1>";
	$i=1;
	?>
	<?php include('tableopen.php'); ?>
	<?php include('table.php'); ?>
	<?php
			$result = $public;
			if($result->num_rows > 1){
				$owner=false;
				?>
				<?php include('table.php'); ?>
	<?php 	} ?>
	<?php include('tableclose.php'); ?>
<?php } ?>
</div>
<body>
</html>
<?php include('dbclose.php'); ?>