<html>
<head>
<link rel='stylesheet' href='http://yui.yahooapis.com/pure/0.4.2/pure-min.css'>
<style>
        .button-success,
        .button-error,
        .button-warning,
        .button-secondary {
            color: white;
            border-radius: 4px;
            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);
        }

        .button-success {
            background: rgb(28, 184, 65); /* this is a green */
        }

        .button-error {
            background: rgb(202, 60, 60); /* this is a maroon */
        }

        .button-warning {
            background: rgb(223, 117, 20); /* this is an orange */
        }

        .button-secondary {
            background: rgb(66, 184, 221); /* this is a light blue */
        }
		.container{margin:auto;width:800px;margin-top:50px;}
		.message{margin:10px 0px 10px 0px;}
		.pad5{padding:5px;}
		.margintop20{margin-top:20px;}
    </style>
</head>