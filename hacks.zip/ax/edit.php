<?php include('constants.php'); ?>
<?php include('dbopen.php'); ?>
<?php
	$id=$_REQUEST['id'];
	$result = mysqli_query($con,'SELECT * FROM urls WHERE id="'.$id.'"');
	while($row = mysqli_fetch_array($result)) {
		$key=$row['keyword'];
		$url=urldecode($row['url']);
		$type=$row['type'];
	}
	$labels=$editlabels;
?>
<?php include('dbclose.php'); ?>
<?php include('header.php'); ?>
<body>
<div class="container">
<?php include("menu.php"); ?>
<?php include("form.php"); ?>
</div>
</body>
</html>