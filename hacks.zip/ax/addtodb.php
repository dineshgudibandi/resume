<?php
include('constants.php');
include('dbopen.php');
$redirect="";
$key=$_REQUEST['key'];
$url=urlencode($_REQUEST['url']);
	if($key==""||$url==""){
		header( 'Location: '.$addlink.'?msg=101');
 	}else if($key=="add"||$key=="urls"){
	    header( 'Location: '.$addlink.'?msg=102');
	}else{
		$type=$_REQUEST['type'];
		$result = mysqli_query($con,'SELECT * FROM urls WHERE keyword="'.$key.'"');
		if($result->num_rows==0)
		{
		    $time= date('Y-m-d H:i:s');
			mysqli_query($con,'INSERT INTO urls(keyword, url, creator,created,type) VALUES ("'.$key.'", "'.$url.'","'.$user.'","'.$time.'","'.$type.'")');
			header( 'Location: '.$mylinks.'?msg=11');
		}else{
			header( 'Location: '.$addlink.'?msg=102');
		}
	}
include('dbclose.php');
?>