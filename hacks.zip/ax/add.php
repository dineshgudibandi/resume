<?php include('constants.php'); ?>
<?php include('header.php'); ?>
<?php 
	$key="";
	$url="";
	$type="1";
	$labels=$addlabels;
	if(isset($_REQUEST['key'])){
		$key.=$_REQUEST['key'];
	}
?> 
<body>
<div class="container">
<?php include("menu.php"); ?>
<?php include('form.php'); ?>
</div>
</body>
</html>