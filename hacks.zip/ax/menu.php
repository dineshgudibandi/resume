<h1><?php echo $apptitle; ?></h1>
<?php echo "Hello ".$user."!"; ?><br/>
<a class="pure-button button-success" href="<?php echo $addlink; ?>"><?php echo $addlinktitle; ?></a>
<a class="pure-button button-secondary" href="<?php echo $mylinks; ?>"><?php echo $mylinkstitle; ?></a>
<a class="pure-button button-warning" href="<?php echo $alllinks; ?>"><?php echo $alllinkstitle; ?></a>
<div class="message">
<?php if(isset($_REQUEST['msg'])){
echo $messages[$_REQUEST['msg']];
}
?> 
</div>