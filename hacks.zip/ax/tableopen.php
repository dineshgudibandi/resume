<table class='pure-table margintop20'>
    <thead>
        <tr>
            <th>#</th>
            <th>Alias</th>
            <th>Url</th>
			<th>Owner</th>
            <th>Type</th>
			<th>Edit</th>
			<th>Delete</th>
        </tr>
    </thead>
    <tbody>